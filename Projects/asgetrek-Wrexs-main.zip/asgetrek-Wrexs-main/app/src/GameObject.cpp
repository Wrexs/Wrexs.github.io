//
// Created by zacpa on 26/11/2020.
//
#include "GameObject.hpp"
#include <memory>
const std::unique_ptr<ASGE::Sprite>& GameObject::getSprite() const
{
  return sprite_;
}
void GameObject::setSprite(std::unique_ptr<ASGE::Sprite>&& sprite)
{
  sprite_ = std::move(sprite);
}
void GameObject::render(ASGE::Renderer* renderer) const
{
  renderer->renderSprite(*sprite_);
}
void GameObject::setCoords(int x, int y)
{
  currentXCoord = x;
  currentYCoord = y;
}
std::pair<int,int> GameObject::getCoords()
{
  return std::pair(static_cast<float>(currentXCoord), static_cast<float>(currentYCoord));
}
int GameObject::getSystem()
{
  return current_system;
}
void GameObject::setSystem(int sector)
{
  current_system = sector;
}
int GameObject::getHealth()
{
  return health;
}
void GameObject::changeHealth(int change) {
  health -= change;
}
void GameObject::resetHealth(int hptotal) {
  health = hptotal;
}
