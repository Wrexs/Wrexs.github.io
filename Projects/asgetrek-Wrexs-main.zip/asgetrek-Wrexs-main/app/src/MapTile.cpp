//
// Created by zacpa on 26/11/2020.
//

#include "MapTile.hpp"
void MapTile::render(ASGE::Renderer* renderer) const
{
  if(visible)
  {
    renderer->renderSprite(*background);
    for (const auto* object : objects)
    {
      object->render(renderer);
    }
  }

}
void MapTile::setPosition(const ASGE::Point2D& position)
{
  position_.x = position.x;
  position_.y = position.y;

  if (background)
  {
    background->xPos(position_.x);
    background->yPos(position_.y);
  }
  for (auto& object : objects)
  {
    object->getSprite()->yPos(position.y);
    object->getSprite()->xPos(position.x);
  }
}
void MapTile::addGameObject(GameObject* gameObject)
{
  auto *object = objects.emplace_back(gameObject);
  object->getSprite()->xPos(position_.x+1);
  object->getSprite()->yPos(position_.y+1);
  occupied = true;
  count++;

if (count == 5)
{

}

}
void MapTile::removeGameObject() {
  objects.pop_back();
  occupied = false;
}

bool MapTile::getOccupied(){

  return occupied;
}

bool MapTile::isVisible() const
{
  return visible;
}
void MapTile::setVisible(bool newvisible)
{
  MapTile::visible = newvisible;
}
GameObject* MapTile::getFirstObject()
{
    return objects[0];

}
