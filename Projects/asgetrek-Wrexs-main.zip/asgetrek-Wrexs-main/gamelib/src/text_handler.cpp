//
// Created by zacpa on 26/11/2020.
//

#include "gamelib/text_handler.hpp"
std::string
text_handler::getString(std::string const input_string, std::string const reason)
{
  std::string output_string;

  if (reason == "intro")
  {
    output_string = "Congratulations on passing the program soldier!\nYou "
                    "have now been granted permission to pilot the UNSC Pillar "
                    "of Winter.\nOur enemy, the Covenant, are assaulting our "
                    "colonies in all known systems.\nIt is your task to "
                    "bring the fight to the Covenant, defend our people and "
                    "eliminate the current "
                    "threat!\n\n\nBefore deployment would you like to run "
                    "through basic training with your crew? [Y/N]" +
                    input_string;
  }
  else if (reason == "briefing1")
  {
    output_string = "As the captain of your ship you are responsible for "
                    "issuing orders to your crew.\n"
                    "The following briefing will bring your crew up to speed "
                    "on each order and how to correctly follow it.\n\n\n"
                    "Press Enter to continue or 'Q' to cancel the briefing "
                    "and begin your journey.";
  }
  else if (reason == "briefing2")
  {
    output_string = "There are many commands you can issue to your crew, such "
                    "as:\n\nMove/M:- \nMove within your current system by entering "
                    "co-ordinates in the form (y,x).\n\nDock/D:- \nDock with a "
                    "nearby "
                    "space ring to replenish resources. Shields need to be down. "
                    "\n\nWarp/W:- \nWarp to a new "
                    "system using co-ordinates in the form (y,x) and local "
                    "co-ordinates in the form (y,x).\nThe energy cost "
                    "is doubled if the shields are raised. "
                    "\n\nEnergy/E:- \nTransfer energy between the 3 vital systems "
                    "of "
                    "the ship. These are\n1.Energy Stores:- Excess energy reserves "
                    "used for warping.\n2.Weapons:- Energy used to power the ship's "
                    "laser weapons.\n3.Shields:- Energy used to power the shield "
                    "system. Incoming damage is redirected to shields.";
  }
  else if (reason == "briefing3")
  {
    output_string = "Laser/L:- \nOur weapon systems will detect all enemy ship's in "
                    "the system and can fire lasers for energy damage.\nIncrements "
                    "of 50 are recommended.\n\n"
                    "Rocket/R:-\nRockets are a limited resource that can be used "
                    "for "
                    "direct damage to enemies.\nMultiple rockets can be prepared "
                    "and "
                    "fired at once. To fire a rocket enter co-ordinates in the form "
                    "(y,x).\n\n"
                    "Shup:-\nRaise shields to reduce incoming damage.\nWarp cost is "
                    "doubled whilst shields are up.\n\n"
                    "Shdn:-\nLower shields to reduce warp cost and dock with "
                    "stations.\nEngaging enemies with shields down can be vary "
                    "dangerous.\n\n";
  }
  else if (reason == "briefing4")
  {
    output_string = "Self/SD:-\nEnter your self destruct code to detonate your warp "
                    "engines and destroy the ship.\nThis should be used as a last "
                    "resort in hopeless situations.\n\n"
                    "Quit:-\nExit the game. \n\n";
  }

  else if (reason == "setup1")
  {
    output_string = "Before you depart we need to correct a few details on your "
                    "profile.\n It appears that we are missing your - \n Name:- ";
  }
  else if (reason == "setup2")
  {
    output_string = "Rank:- ";
  }
  else if (reason == "setup3")
  {
    output_string = "Destruct Code:- ";
  }

  return output_string;
}
