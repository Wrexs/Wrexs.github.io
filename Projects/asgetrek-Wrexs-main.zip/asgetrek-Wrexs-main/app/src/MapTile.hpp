//
// Created by zacpa on 26/11/2020.
//

#ifndef ASGETREK_MAPTILE_HPP
#define ASGETREK_MAPTILE_HPP

#include "GameObject.hpp"
#include <Engine/Sprite.h>
#include <memory>
#include <vector>
namespace  ASGE{ class Renderer; }
class MapTile
{
 public:
  void render(ASGE::Renderer* renderer) const;
  std::unique_ptr<ASGE::Sprite> background {nullptr};



 private:
  int count = 0;
  ASGE::Point2D position_ {0,0};
  std::vector<GameObject*> objects;
  bool occupied = false;
  bool visible = false;

 public:
  bool isVisible() const;
  void setVisible(bool newvisible);

 public:
  void addGameObject(GameObject* gameObject);
  void setPosition(const ASGE::Point2D& position);
  void removeGameObject();
  bool getOccupied();
  GameObject* getFirstObject();

};

#endif // ASGETREK_MAPTILE_HPP
