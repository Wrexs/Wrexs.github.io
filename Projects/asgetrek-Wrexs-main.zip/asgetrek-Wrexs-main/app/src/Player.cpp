//
// Created by zacpa on 26/11/2020.
//
#include "Player.hpp"
#include <Engine/Renderer.h>
Player::Player(ASGE::Renderer* renderer)
{
  auto unique_sprite = renderer->createUniqueSprite();
  this->setSprite(std::move(unique_sprite));
}
bool Player::loadTexture(const std::string& texture_path)
{
  return this->getSprite()->loadTexture(texture_path);
}
void Player::setScale(float scale)
{
  this->getSprite()->scale(scale);
}
void Player::setPosition(ASGE::Point2D pos)
{
  this->getSprite()->xPos(pos.x);
  this->getSprite()->yPos(pos.y);
}
void Player::setWidth(float width)
{
  return this->getSprite()->width(width);
}
void Player::setHeight(float height)
{
  return this->getSprite()->height(height);
}
int Player::getCurrentShields() const
{
  return shields_energy;
}
void Player::setCurrentShields(int newShields)
{
  shields_energy = newShields;
}
bool Player::isShieldsUp() const
{
  return shields_up;
}
void Player::setShieldsUp(bool shieldsStatus)
{
  shields_up = shieldsStatus;
}
int Player::getRocketCount() const
{
  return rocket_count;
}
void Player::restock()
{
  rocket_count = MAX_ROCKETS;

  weapons_energy = MAX_ENERGY;
  stored_energy  = MAX_ENERGY * 2;
  shields_energy = MAX_ENERGY;
}
void Player::changeRocketCount(int RocketsUsed)
{
  rocket_count -= RocketsUsed;
}
int Player::getEnergyStores() const
{
  return stored_energy;
}
void Player::setEnergyStores(int energyStores)
{
  stored_energy = energyStores;
}
int Player::getWeaponsEnergy() const
{
  return weapons_energy;
}
void Player::setWeaponsEnergy(int weaponsEnergy)
{
  weapons_energy = weaponsEnergy;
}
void Player::incomingDamage(int damage)
{
  if (shields_up)
  {
    if (damage * 10 < shields_energy)
    {
      shields_energy -= damage * 10;
    }
    else
    {
      int excess_damage = -((shields_energy / 10) - damage);
      shields_energy    = 0;
      changeHealth(excess_damage);
    }
  }
  else
  {
    changeHealth(damage);
  }
}
