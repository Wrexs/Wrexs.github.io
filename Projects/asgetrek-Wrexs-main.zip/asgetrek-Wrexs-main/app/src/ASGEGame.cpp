#include "ASGEGame.hpp"

/// Initialises the game.
/// Setup your game and initialise the core components.
/// @param settings
ASGETrek::ASGETrek(const ASGE::GameSettings& settings) : OGLGame(settings)
{
  key_callback_id = inputs->addCallbackFnc(ASGE::E_KEY, &ASGETrek::keyHandler, this);
  inputs->use_threads = true;
  // toggleFPS();

  initScreen();
  initTitleBackground();
  initIntroBackground();
  initGameBackground();
  initFonts();
  initPlayer();
  firstSetup();
}

/// Destroys the game.
ASGETrek::~ASGETrek()
{
  this->inputs->unregisterCallback(static_cast<unsigned int>(key_callback_id));
}

/// Processes key inputs.
/// This function is added as a callback to handle the game's
/// keyboard input. For this game, calls to this function
/// are not thread safe, so you may alter the game's state
/// but your code needs to designed to prevent data-races.
/// @param data
/// @see KeyEvent
void ASGETrek::keyHandler(ASGE::SharedEventData data)
{
  const auto* key = dynamic_cast<const ASGE::KeyEvent*>(data.get());

  if (key->action == ASGE::KEYS::KEY_PRESSED)
  {
    if (key->key == ASGE::KEYS::KEY_ESCAPE)
    {
      if (state == 0)
      {
        signalExit();
      }
      else if (state == 4 && destructing)
      {
        destructing = false;
        actions_completed--;
        actionCompleted();
      }
    }

    if (state == 0)
    {
      if (key->key == ASGE::KEYS::KEY_ENTER)
      {
        state = 1;
        stateChange();
      }
    }

    else
    {
      if (command_input)
      {
        if (key->key == ASGE::KEYS::KEY_ESCAPE)
        {
        }
        else if (key->key == ASGE::KEYS::KEY_SPACE)
        {
        }
        else if (key->key == ASGE::KEYS::KEY_BACKSPACE && input_string.length() > 0)
        {
          input_string.pop_back();
        }
        else if (key->key == ASGE::KEYS::KEY_Q && state == 2)
        {
          state = 3;
        }
        else if (key->key == ASGE::KEYS::KEY_ENTER)
        {
          if (state == 2)
          {
            if (briefing_Page < 4)
            {
              briefing_Page++;
              setupGameText();
            }
            else
            {
              state = 3;
              stateChange();
            }
          }
          else if (state == 3)
          {
            if (player_name.empty() && input_string.length() > 0)
            {
              player_name = input_string;
              input_string.clear();
              allow_Ints  = true;
              allow_Chars = false;
              MAX_CHARS   = 1;
            }
            else if (player_rank == 0 && input_string.length() > 0)
            {
              if(std::stoi(input_string)> 0 && std::stoi(input_string)<6)
              {
                player_rank = std::stoi(input_string);
                input_string.clear();
                allow_Chars = true;
                MAX_CHARS   = 7;
              }
              else
              {
                input_string.clear();
              }
            }
            else if (destruct_code.empty() && input_string.length() > 0)
            {
              destruct_code = input_string;
              input_string.clear();
              state    = 4;
              info_str = "PILLAR OF WINTER \n\nCAPTAIN NAME: " + player_name +
                         "\nRANK: " + std::to_string(player_rank);
              stateChange();
            }
          }
          else
          {
            resolveCommands();
          }
        }

        // Add key to input_string if allowed chars and key is a char
        else if (
          ((key->key >= 65 && key->key <= 90) ||
           (key->key >= 97 && key->key <= 122)) &&
          allow_Chars && static_cast<float>(input_string.length()) < MAX_CHARS)
        {
          input_string += static_cast<char>(key->key);
        }

        // Add key to input_string if allowed ints and key is an int
        else if (
          ((key->key >= 48 && key->key <= 57) || key->key == 44) && allow_Ints &&
          static_cast<float>(input_string.length()) < MAX_CHARS)
        {
          input_string += static_cast<char>(key->key);
        }
      }
    }
  }
}

bool ASGETrek::initTitleBackground()
{
  title_Background = renderer->createUniqueSprite();
  if (!title_Background->loadTexture("/data/Images/MenuBackground.png"))
  {
    return false;
  }

  title_Background->setGlobalZOrder(0);
  title_Background->width(static_cast<float>(ASGE::SETTINGS.window_width));
  title_Background->height(static_cast<float>(ASGE::SETTINGS.window_height));
  title_Background->xPos(0);
  title_Background->yPos(0);
  return true;
}

/// Updates your game and all it's components.
/// @param us
void ASGETrek::update(const ASGE::GameTime& us)
{
  for (auto& gc : game_components)
  {
    gc->update(us.deltaInSecs());
  }
  setupTextInput();
  setupGameText();

  if (!targets_list.empty() && enemyTurn)
  {
    enemyActions();
  }
}

/// Render your game and its scenes here.
void ASGETrek::render()
{
  if (state == 0)
  {
    renderer->renderSprite(*title_Background);
    renderer->renderText(title_Text);
  }
  else if (state == 1)
  {
    renderer->renderSprite(*intro_Background);
    renderer->renderText(intro_Text);
  }
  else if (state == 2)
  {
    renderer->renderSprite(*intro_Background);
    renderer->renderText(intro_Text);
  }
  else if (state == 3)
  {
    renderer->renderSprite(*intro_Background);
    renderer->renderText(intro_Text);
  }
  else if (state == 4)
  {
    renderer->renderSprite(*game_Background);
    renderer->renderText(input_Text);
    renderer->renderText(x_axis_display);
    renderer->renderText(y_axis_display);
    renderer->renderText(enemy_log);
    renderer->renderText(combat_log);
    renderer->renderText(player_log);
    renderer->renderText(stored_energy);
    renderer->renderText(weapons_energy);
    renderer->renderText(shields_energy);
    renderer->renderText(info);

    if (!action.empty())
    {
      renderer->renderText(current_action);
    }
    if (!feedback.empty())
    {
      renderer->renderText(action_feedback);
    }

    renderer->renderText(player_health);
    renderer->renderText(player_rockets);
    renderer->renderText(status);
    game_map->render(renderer.get());

    for (int i = 0; i < 64; i++)
    {
      renderer->renderText(grid_texts[static_cast<size_t>(i)]);
    }
  }
  else if (state == 5)
  {
    renderer->renderSprite(*intro_Background);
    renderer->renderText(game_over);
    renderer->renderText(game_over_score);
  }
}

/// Calls to fixedUpdate use the same fixed timesteps
/// irrespective of how much time is passed. This allows
/// calculations to resolve correctly and stop physics
/// simulations from imploding
///
/// https://gamedev.stackexchange.com/questions/1589/when-should-i-use-a-fixed-or-variable-time-step
/// "Use variable timesteps for your game and fixed steps for physics"
/// @param us
void ASGETrek::fixedUpdate(const ASGE::GameTime& us)
{
  Game::fixedUpdate(us);
}

// Sets string values for ASGE::Text's
void ASGETrek::setupTextInput()
{
  title_Text.setString("Space Rings");
  input_Text.setString(input_string);
  current_action.setString(action);
  enemy_log.setString(enemy_log_input);
  combat_log.setString(combat_log_input);
  player_log.setString(player_log_input);
  action_feedback.setString(feedback);
  player_health.setString(player_health_str);
  player_rockets.setString(player_rocket_str);
  status.setString("-STATUS-");
  x_axis_display.setString("1    2    3    4    5    6    7    8");
  y_axis_display.setString("1\n2\n3\n4\n5\n6\n7\n8");
  stored_energy.setString(stored_energy_str);
  weapons_energy.setString(weapons_energy_str);
  shields_energy.setString(shield_energy_str);
  game_over.setString("GAME OVER");
  game_over_score.setString(game_over_str);
  info.setString(info_str);
}

// Sets up Font values and scales for ASGE::Text's
void ASGETrek::initFonts()
{
  createFont("/data/Fonts/Title Font/Halo.ttf", "Title", 120);
  title = &renderer->getFont(font_idx);
  title_Text.setFont(*title);
  title_Text.setColour(ASGE::COLOURS::SILVER);
  title_Text.setPosition({ static_cast<float>((ASGE::SETTINGS.window_width) / 5.5),
                           static_cast<float>((ASGE::SETTINGS.window_height / 4)) });

  createFont("/data/Fonts/Display Font/nasalization-rg.ttf", "Display", 48);
  display = &renderer->getFont(font_idx);
  input_Text.setFont(*display);
  intro_Text.setFont(*display);
  current_action.setFont(*display);
  action_feedback.setFont(*display);
  player_health.setFont(*display);
  player_rockets.setFont(*display);
  x_axis_display.setFont(*display);
  y_axis_display.setFont(*display);
  game_over.setFont(*display);
  game_over_score.setFont(*display);
  status.setFont(*display);
  enemy_log.setFont(*display);
  combat_log.setFont(*display);
  player_log.setFont(*display);
  stored_energy.setFont(*display);
  weapons_energy.setFont(*display);
  shields_energy.setFont(*display);
  info.setFont(*display);
  game_over_score.setColour(ASGE::COLOURS::GRAY);
  stored_energy.setColour(ASGE::COLOURS::CYAN);
  weapons_energy.setColour(ASGE::COLOURS::CYAN);
  shields_energy.setColour(ASGE::COLOURS::CYAN);
  status.setColour(ASGE::COLOURS::CYAN);
  player_health.setColour(ASGE::COLOURS::CYAN);
  player_rockets.setColour(ASGE::COLOURS::CYAN);
  enemy_log.setColour(ASGE::COLOURS::RED);
  combat_log.setColour(ASGE::COLOURS::ORANGERED);
  player_log.setColour(ASGE::COLOURS::GREEN);

  input_Text.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.1),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.94) });
  current_action.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.02),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.64) });
  action_feedback.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.02),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.78) });

  player_health.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.12) });
  player_rockets.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.16) });
  stored_energy.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.20) });
  weapons_energy.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.24) });
  shields_energy.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.28) });
  status.setPosition({ static_cast<float>(ASGE::SETTINGS.window_width * 0.4),
                       static_cast<float>(ASGE::SETTINGS.window_height * 0.065) });

  x_axis_display.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.055),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.05) });
  y_axis_display.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.025),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.1) });

  enemy_log.setPosition({ static_cast<float>(ASGE::SETTINGS.window_width * 0.7),
                          static_cast<float>(ASGE::SETTINGS.window_height * 0.46) });
  combat_log.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.7),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.73) });
  player_log.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.38),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.72) });
  game_over.setPosition({ static_cast<float>(ASGE::SETTINGS.window_width * 0.4),
                          static_cast<float>(ASGE::SETTINGS.window_height * 0.15) });
  game_over_score.setPosition(
    { static_cast<float>(ASGE::SETTINGS.window_width * 0.35),
      static_cast<float>(ASGE::SETTINGS.window_height * 0.25) });

  info.setPosition({ static_cast<float>(ASGE::SETTINGS.window_width * 0.365),
                     static_cast<float>(ASGE::SETTINGS.window_height * 0.39) });

  enemy_log.setScale(0.5F);
  combat_log.setScale(0.5F);
  player_log.setScale(0.5F);
  x_axis_display.setScale(0.7F);
  y_axis_display.setScale(0.7F);
  player_rockets.setScale(0.6F);
  player_health.setScale(0.6F);
  status.setScale(0.85F);
  stored_energy.setScale(0.6F);
  weapons_energy.setScale(0.6F);
  shields_energy.setScale(0.6F);
  game_over_score.setScale(0.75F);
  info.setScale(0.75F);

  action_feedback.setScale(0.85F);
  intro_Text.setPosition({ 190, 100 });
  intro_Text.setScale(0.6F);

  createFont("/data/Fonts/Monospaced Font/VeraMono-Bold.ttf", "Grid", 12);
  grid = &renderer->getFont(font_idx);
  grid_text.setFont(*grid);
  grid_text.setPosition({ 920, 60 });
  grid_text.setColour(ASGE::COLOURS::SEAGREEN);

  int spacingcount = 0;
  float y_offset   = 0;
  float x_offset   = 0;
  for (int i = 0; i < 64; i++)
  {
    grid_texts[static_cast<size_t>(i)].setFont(*grid);
    grid_texts[static_cast<size_t>(i)].setPosition(
      { 920 + x_offset, 60 + y_offset });
    grid_texts[static_cast<size_t>(i)].setColour(ASGE::COLOURS::SEAGREEN);
    grid_texts[static_cast<size_t>(i)].setScale(1);
    grid_texts[static_cast<size_t>(i)].setString(
      grid_strings[static_cast<size_t>(i)]);
    x_offset += 40;

    spacingcount++;
    if (spacingcount == 8)
    {
      y_offset += 30;
      spacingcount = 0;
      x_offset     = 0;
    }
  }
}

void ASGETrek::createFont(const std::string& filepath, const char* name, int pt)
{
  ASGE::FILEIO::File font_file;
  if (font_file.open(filepath))
  {
    auto buffer = font_file.read();
    font_idx    = renderer->loadFontFromMem(
      name, buffer.as_unsigned_char(), static_cast<unsigned int>(buffer.length), pt);
    font_file.close();
  }
}
void ASGETrek::initScreen()
{
  ASGE::SETTINGS.window_title = "Space Rings";
}
void ASGETrek::resolveCommands()
{
  if (state == 1)
  {
    if (input_string == "Y")
    {
      state = 2;
      stateChange();
    }
    else if (input_string == "N")
    {
      state = 3;
      stateChange();
    }
  }

  else if (state == 2)
  {
  }

  else if (state == 3)
  {
  }

  else if (state == 4)
  {
    if (input_string == "QUIT")
    {
      signalExit();
    }

    //
    // Moving Energy
    //
    else if (movingEnergy && input_string.length() > 0)
    {
      if (energyFrom != 0 && energyTo == 0)
      {
        energyTo = std::stoi(input_string);
        if ((energyTo >= 4 || energyTo <= 0) || energyTo == energyFrom)
        {
          player_log_input += "Invalid sources specified.\n";
          energyTo   = 0;
          energyFrom = 0;
          actions_completed--;
          actionCompleted();
          setupInput("default");
        }
        else
        {
          feedback = "Energy to move?";
          setupInput("longnumber");
        }
      }
      else if (energyFrom != 0 && energyTo != 0)
      {
        int energy_val = std::stoi(input_string);
        if (energyFrom == 1 && player_->getEnergyStores() >= energy_val)
        {
          player_->setEnergyStores(player_->getEnergyStores() - energy_val);
          if (energyTo == 2)
          {
            player_->setWeaponsEnergy(player_->getWeaponsEnergy() + energy_val);
          }
          else if (energyTo == 3)
          {
            player_->setCurrentShields(player_->getCurrentShields() + energy_val);
          }
        }
        else if (energyFrom == 2 && player_->getWeaponsEnergy() >= energy_val)
        {
          player_->setWeaponsEnergy(player_->getWeaponsEnergy() - energy_val);
          if (energyTo == 1)
          {
            player_->setEnergyStores(player_->getEnergyStores() + energy_val);
          }

          else if (energyTo == 3)
          {
            player_->setCurrentShields(player_->getCurrentShields() + energy_val);
          }
        }
        else if (energyFrom == 3 && player_->getCurrentShields() >= energy_val)
        {
          player_->setCurrentShields(player_->getCurrentShields() - energy_val);
          if (energyTo == 1)
          {
            player_->setEnergyStores(player_->getEnergyStores() + energy_val);
          }

          else if (energyTo == 2)
          {
            player_->setWeaponsEnergy(player_->getWeaponsEnergy() + energy_val);
          }
        }
        movingEnergy = false;
        energyFrom   = 0;
        energyTo     = 0;
        actions_completed--;
        actionCompleted();
      }
      else
      {
        energyFrom = std::stoi(input_string);
        feedback   = "To where? 1,2,3";
        if (energyFrom >= 4 || energyFrom <= 0)
        {
          energyFrom   = 0;
          movingEnergy = false;
          player_log_input += "Invalid source specified.\n";
          setupInput("default");
          actions_completed--;
          actionCompleted();
        }
      }
      stored_energy_str = "1.ENERGY: " + std::to_string(player_->getEnergyStores());
      weapons_energy_str =
        "2.WEAPONS: " + std::to_string(player_->getWeaponsEnergy());
      shield_energy_str =
        "3.SHIELDS: " + std::to_string(player_->getCurrentShields());
    }

    //
    // Self Destruct
    //
    else if (destructing)
    {
      if (input_string == destruct_code)
      {
        player_->changeHealth(100);
        gameOver();
      }
      else
      {
        destructing = false;
        actions_completed--;
        actionCompleted();
      }
    }

    //
    // Lasers
    //
    else if (firing_laser && input_string.length() > 0)
    {
      GameObject* current_enemy = targets_list.at(0);
      int enemy_x               = static_cast<int>(current_enemy->getCoords().first);
      int enemy_y = static_cast<int>(current_enemy->getCoords().second);

      if (player_->getWeaponsEnergy() >= std::stoi(input_string))
      {
        player_->setWeaponsEnergy(
          player_->getWeaponsEnergy() - std::stoi(input_string));
        weapons_energy_str =
          "2.WEAPONS: " + std::to_string(player_->getWeaponsEnergy());
        current_enemy->changeHealth(std::stoi(input_string) / 10);
        combat_log_input += "Laser fired at enemy in " + std::to_string(enemy_x) +
                            "," + std::to_string(enemy_y) + " for " +
                            std::to_string(std::stoi(input_string) / 10) +
                            " damage.\n";
        if (current_enemy->getHealth() <= 0)
        {
          enemy_log_input += "Enemy at " + std::to_string(enemy_x) + "," +
                             std::to_string(enemy_y) + " has been defeated.\n";
          auto& get_enemy_tile = game_map->getLoc(
            { current_enemy->getCoords().first, current_enemy->getCoords().second },
            current_system);
          get_enemy_tile.removeGameObject();
          current_enemy->setSystem(-1);
          current_enemy->setCoords(0, 0);
          generateChart();
          defeated_enemies++;
          if (defeated_enemies >= max_used_enemies)
          {
            gameOver();
          }
        }
        targets_list.erase(targets_list.begin());
      }
      else
      {
        combat_log_input += "Not enough energy allocated to weapons.\n";
      }

      if (targets_list.empty())
      {
        firing_laser = false;
        actionCompleted();
        setupInput("default");
        generateEnemyList();
      }
      else
      {
        int target_x = static_cast<int>(targets_list.front()->getCoords().first);
        int target_y = static_cast<int>(targets_list.front()->getCoords().second);
        feedback     = "ENTER LASER POWER at " + std::to_string(target_x) + "," +
                   std::to_string(target_y);
      }
    }
    //
    // Rockets
    //
    else if (firing_rocket && input_string.length() > 0)
    {
      if (rockets_readied == 0 && input_string.length() == 1)
      {
        if (player_->getRocketCount() >= std::stoi(input_string))
        {
          rockets_readied = std::stoi(input_string);
          player_->changeRocketCount(rockets_readied);
          player_rocket_str =
            "ROCKETS: " + std::to_string(player_->getRocketCount());
          MAX_CHARS = 3;
          feedback  = "CO-ORDS TO FIRE?";
        }
        else
        {
          firing_rocket = false;
          actionCompleted();
          setupInput("default");
        }
      }
      else if (rockets_readied > 0)
      {
        std::pair<int, int> temp_coords;
        temp_coords = findCoords(input_string);

        if (temp_coords.first != 0 && temp_coords.second != 0)
        {
          auto& target_tile = game_map->getLoc(temp_coords, current_system);
          if (target_tile.getOccupied())
          {
            target_tile.getFirstObject()->changeHealth(40);

            if (
              (static_cast<int>(player_->getCoords().first) == temp_coords.first) &&
              static_cast<int>(player_->getCoords().second) == temp_coords.second)
            {
              combat_log_input += "Hit self with a rocket for 40 damage.\n We "
                                  "should avoid this.\n";
            }
            else
            {
              combat_log_input += "Target at " + std::to_string(temp_coords.first) +
                                  "," + std::to_string(temp_coords.second) +
                                  " has been hit by a rocket for 40 damage.\n";

              if (target_tile.getFirstObject()->getHealth() <= 0)
              {
                enemy_log_input += "Enemy at " + std::to_string(temp_coords.first) +
                                   "," + std::to_string(temp_coords.second) +
                                   " has been defeated.\n";
                defeated_enemies++;
                if (defeated_enemies >= max_used_enemies)
                {
                  gameOver();
                }
                target_tile.getFirstObject()->setSystem(-1);
                target_tile.getFirstObject()->setCoords(0, 0);
                target_tile.removeGameObject();
                generateChart();
              }
            }
          }
          else
          {
            combat_log_input +=
              "Missile fired at " + std::to_string(temp_coords.first) + "," +
              std::to_string(temp_coords.second) + " has missed.\n";
          }

          rockets_readied--;

          if (rockets_readied == 0)
          {
            firing_rocket = false;
            actionCompleted();
            setupInput("default");
            generateEnemyList();
          }
        }
      }
    }
    //
    // Moving and destination cell for warping
    //
    else if (input_string.length() == 3 && input_string.find(',') && input_coords)
    {
      std::pair<int, int> temp_coords;
      temp_coords = findCoords(input_string);
      if (temp_coords.first != 0 && temp_coords.second != 0)
      {
        if (!warping)
        {
          movePlayer(temp_coords.first, temp_coords.second);
        }
        else
        {
          warpPlayer(temp_coords.first, temp_coords.second);
          warping = false;
        }
        generateEnemyList();
        generateChart();
      }

      input_coords = false;
      actionCompleted();
      setupInput("default");
    }
    //
    // System target for warping
    //
    else if (input_string.length() == 3 && input_string.find(',') && warping)
    {
      std::pair<int, int> temp_coords;
      temp_coords = findCoords(input_string);

      if (temp_coords.first != 0 && temp_coords.second != 0)
      {
        int player_y_system = (player_->getSystem() / game_map->SYSTEM_WIDTH) + 1;
        int player_x_system =
          (player_->getSystem() - ((player_y_system - 1) * 8)) + 1;

        int x_diff = player_x_system - temp_coords.second;
        int y_diff = player_y_system - temp_coords.first;

        if (x_diff < 0)
        {
          x_diff *= -1;
        }
        if (y_diff < 0)
        {
          y_diff *= -1;
        }
        if (player_->isShieldsUp())
        {
          fuel_cost = (x_diff + y_diff) * 200;
          player_log_input += "Increased energy cost due to active shields.\n "
                              "Deactivate for reduced cost.\n";
        }
        else
        {
          fuel_cost = (x_diff + y_diff) * 100;
        }

        player_log_input += "Warping to " + std::to_string(temp_coords.second) +
                            "," + std::to_string(temp_coords.first) +
                            " with a cost of " + std::to_string(fuel_cost) +
                            " energy.\n";
        if ((player_->getEnergyStores() - fuel_cost) >= 0)
        {
          target_system =
            (((temp_coords.first - 1) * game_map->SYSTEM_WIDTH) +
             (temp_coords.second - 1));
          input_coords = true;
          feedback     = "ENTER CO-ORDS";
        }
        else
        {
          player_log_input += "We do not have enough energy for this warp.\n "
                              "Exiting Warp Mode.";
          fuel_cost = 0;
          setupInput("default");
          warping = false;
        }
      }
      else
      {
        player_log_input += "Invalid Co-ordinates specified.\n "
                            "Exiting Warp Mode.";
        setupInput("default");
        warping = false;
      }
    }
    //
    // Command Handling
    //
    else if (!input_coords && !warping)
    {
      if (input_string == "W" || input_string == "WARP")
      {
        warping = true;
        setupInput("coords");
        actionEntered();
        action   = "WARPING";
        feedback = "ENTER TARGET SYSTEM";
      }
      else if (input_string == "M" || input_string == "MOVE")
      {
        input_coords = true;
        setupInput("coords");
        action   = "MOVING";
        feedback = "ENTER CO-ORDS";
        actionEntered();
      }
      else if (input_string == "S" || input_string == "SPEED")
      {
      }
      else if (input_string == "L" || input_string == "LASER")
      {
        for (int i = 0; i < max_used_enemies; i++)
        {
          if (enemy[i]->getSystem() == current_system)
          {
            addToTargets(enemy[i].get());
          }
        }
        if (!targets_list.empty())
        {
          actionEntered();
          firing_laser = true;
          setupInput("longnumber");
          action       = "FIRING LASER";
          int target_x = static_cast<int>(targets_list.front()->getCoords().first);
          int target_y = static_cast<int>(targets_list.front()->getCoords().second);
          action_feedback.setScale(0.75);
          feedback = "ENTER LASER POWER at " + std::to_string(target_x) + "," +
                     std::to_string(target_y);
        }
        else
        {
          combat_log_input += "No enemies nearby.\n";
        }
      }

      else if (input_string == "R" || input_string == "ROCKET")
      {
        if (player_->getRocketCount() > 0)
        {
          actionEntered();
          firing_rocket = true;
          setupInput("shortnumber");
          action   = "FIRING ROCKET";
          feedback = "NUMBER TO FIRE?";
        }
        else
        {
          combat_log_input += "Not enough rockets available.\n";
        }
      }
      else if (input_string == "F" || input_string == "FIX")
      {
      }
      else if (input_string == "E" || input_string == "ENERGY")
      {
        movingEnergy = true;
        actionEntered();
        feedback = "From where? 1,2,3";
        action   = "Move Energy";
        setupInput("shortnumber");
      }
      else if (input_string == "SHDN")
      {
        player_->setShieldsUp(false);
        shields_energy.setColour(ASGE::COLOURS::RED);
        player_log_input += "Shields lowered.\n";
      }
      else if (input_string == "SHUP" && player_->getCurrentShields() > 0)
      {
        player_->setShieldsUp(true);
        shields_energy.setColour(ASGE::COLOURS::CYAN);
        player_log_input += "Shields raised.\n";
      }
      else if (input_string == "SD" || input_string == "SELF")
      {
        destructing = true;
        action      = "SELFDESTRUCT";
        feedback    = "ENTER CODE";
        setupInput("destruct");
        actionEntered();
      }
      else if (input_string == "D" || input_string == "DOCK")
      {
        for (int i = 0; i < MAX_SPACE_RINGS; i++)
        {
          if (
            space_ring[i]->getSystem() == current_system &&
            adjacencyCheck(player_->getCoords(), space_ring[i]->getCoords()))
          {
            if (player_->isShieldsUp())
            {
              player_log_input += "Lower shields to dock.\n";
            }
            else
            {
              player_->restock();
              times_refueled++;
              player_health_str = "HEALTH: " + std::to_string(player_->getHealth());
              player_rocket_str =
                "ROCKETS: " + std::to_string(player_->getRocketCount());
              stored_energy_str =
                "1.ENERGY: " + std::to_string(player_->getEnergyStores());
              weapons_energy_str =
                "2.WEAPONS: " + std::to_string(player_->getWeaponsEnergy());
              shield_energy_str =
                "3.SHIELDS: " + std::to_string(player_->getCurrentShields());
              int space_ring_x = static_cast<int>(space_ring[i]->getCoords().first);
              int space_ring_y = static_cast<int>(space_ring[i]->getCoords().second);
              actionEntered();
              player_log_input = "Docked with station at " +
                                 std::to_string(space_ring_x) + "," +
                                 std::to_string(space_ring_y) +
                                 ".\n"
                                 "Restored Energy and Rockets\n";
            }
          }
        }
      }
    }
    // Reset values if input not recognised
    else
    {
      input_coords = false;
      warping      = false;
      setupInput("default");
    }
  }
  input_string.clear();
}

// Called when state is changed to setup the new scene
void ASGETrek::stateChange()
{
  if (state == 1)
  {
    setupGameText();
    allow_Chars = true;
    allow_Ints  = false;
  }
  if (state == 2)
  {
    setupGameText();
  }
  if (state == 3)
  {
    setupInput("default");
    setupGameText();
  }
  if (state == 4)
  {
    auto& place_player_tile = game_map->getLoc(
      { player_->getCoords().first, player_->getCoords().second }, current_system);
    place_player_tile.addGameObject(player_.get());

    allow_Ints  = true;
    allow_Chars = true;

    for (int i = 1; i < game_map->SYSTEM_WIDTH + 1; i++)
    {
      for (int j = 1; j < game_map->SYSTEM_WIDTH + 1; j++)
      {
        auto& get_tile = game_map->getLoc({ i, j }, current_system);
        get_tile.setVisible(true);
      }
    }

    for (int i = 0; i < 64; i++)
    {
      system_known[static_cast<size_t>(i)] = 0;
    }

    initEnemies();
    initSpaceRings();

    revealMap();
    generateChart();
    player_health_str  = "HEALTH: " + std::to_string(player_->getHealth());
    player_rocket_str  = "ROCKETS: " + std::to_string(player_->getRocketCount());
    stored_energy_str  = "1.ENERGY: " + std::to_string(player_->getEnergyStores());
    weapons_energy_str = "2.WEAPONS: " + std::to_string(player_->getWeaponsEnergy());
    shield_energy_str = "3.SHIELDS: " + std::to_string(player_->getCurrentShields());
  }
}

bool ASGETrek::initIntroBackground()
{
  intro_Background = renderer->createUniqueSprite();
  if (!intro_Background->loadTexture("/data/Images/GameScreen3.png"))
  {
    return false;
  }

  intro_Background->setGlobalZOrder(0);
  intro_Background->width(static_cast<float>(ASGE::SETTINGS.window_width));
  intro_Background->height(static_cast<float>(ASGE::SETTINGS.window_height));
  intro_Background->xPos(0);
  intro_Background->yPos(0);
  return true;
}

bool ASGETrek::initGameBackground()
{
  game_Background = renderer->createUniqueSprite();
  if (!game_Background->loadTexture("/data/Images/GameScreen2.png"))
  {
    return false;
  }

  game_Background->setGlobalZOrder(0);
  game_Background->width(static_cast<float>(ASGE::SETTINGS.window_width));
  game_Background->height(static_cast<float>(ASGE::SETTINGS.window_height));
  game_Background->xPos(0);
  game_Background->yPos(0);
  return true;
}

// Calls texthandler for a block of text to use in intro_Text
void ASGETrek::setupGameText()
{
  if (state == 1)
  {
    intro_Text.setString(text_handler::getString(input_string, "intro"));
  }
  else if (state == 2)
  {
    if (briefing_Page == 1)
    {
      intro_Text.setString(text_handler::getString(input_string, "briefing1"));
    }
    if (briefing_Page == 2)
    {
      intro_Text.setString(text_handler::getString(input_string, "briefing2"));
    }
    if (briefing_Page == 3)
    {
      intro_Text.setString(text_handler::getString(input_string, "briefing3"));
    }
    if (briefing_Page == 4)
    {
      intro_Text.setString(text_handler::getString(input_string, "briefing4"));
    }
  }
  else if (state == 3)
  {
    if (player_name.empty())
    {
      intro_Text.setString(
        text_handler::getString(input_string, "setup1") + input_string);
    }
    else if (player_rank == 0)
    {
      intro_Text.setString(
        text_handler::getString(input_string, "setup1") + player_name + "\n" +
        text_handler::getString(input_string, "setup2") + input_string);
    }
    else if (destruct_code.empty())
    {
      intro_Text.setString(
        text_handler::getString(input_string, "setup1") + player_name + "\n" +
        text_handler::getString(input_string, "setup2") +
        std::to_string(player_rank) + "\n" +
        text_handler::getString(input_string, "setup3") + input_string);
    }
  }
}

bool ASGETrek::initPlayer()
{
  player_ = std::make_unique<Player>(renderer.get());
  player_->setScale(1);
  player_->getSprite()->setGlobalZOrder(100);
  srand(static_cast<unsigned>(time(nullptr)));
  int rng_x      = rand() % 8 + 1;
  int rng_y      = rand() % 8 + 1;
  int rng_system = rand() % 63;
  player_->setCoords(rng_x, rng_y);
  player_->setSystem(rng_system);
  current_system = rng_system;

  if (!player_->loadTexture("/data/Images/PlayerShip.png"))
  {
    return false;
  }

  return true;
}

void ASGETrek::movePlayer(int x, int y)
{
  auto& move_to_tile = game_map->getLoc({ x, y }, current_system);
  if (!move_to_tile.getOccupied())
  {
    auto& move_from_tile = game_map->getLoc(
      { player_->getCoords().first, player_->getCoords().second }, current_system);
    if (move_from_tile.getOccupied())
    {
      move_from_tile.removeGameObject();
    }

    move_to_tile.addGameObject(player_.get());
    player_->setCoords(x, y);
    input_string.clear();
  }
  else
  {
    player_log_input += "Movement failed, location occupied.\n";
  }
}

void ASGETrek::warpPlayer(int x, int y)
{
  auto& move_to_tile = game_map->getLoc({ x, y }, target_system);
  if (!move_to_tile.getOccupied())
  {
    auto& move_from_tile = game_map->getLoc(
      { player_->getCoords().first, player_->getCoords().second }, current_system);
    if (move_from_tile.getOccupied())
    {
      move_from_tile.removeGameObject();
    }

    move_to_tile.addGameObject(player_.get());
    player_->setEnergyStores(player_->getEnergyStores() - fuel_cost);
    stored_energy_str = "1.ENERGY: " + std::to_string(player_->getEnergyStores());
    player_->setSystem(target_system);
    for (int i = 1; i < game_map->SYSTEM_WIDTH + 1; i++)
    {
      for (int j = 1; j < game_map->SYSTEM_WIDTH + 1; j++)
      {
        auto& get_current_tile = game_map->getLoc({ i, j }, current_system);
        get_current_tile.setVisible(false);

        auto& get_target_tile = game_map->getLoc({ i, j }, target_system);
        get_target_tile.setVisible(true);
      }
    }

    player_->setCoords(x, y);
    current_system                                    = target_system;
    system_known[static_cast<size_t>(current_system)] = 1;
    revealMap();

    input_string.clear();
  }
  else
  {
    player_log_input += "Warp failed, destination occupied.\n";
  }
}

// Turn string into x,y co-ords with error correction.
std::pair<int, int> ASGETrek::findCoords(std::string const& str)
{
  int const X = std::atoi(str.c_str());
  int const Y = std::atoi(str.c_str() + str.find(',') + 1);

  if (X > game_map->SYSTEM_WIDTH || Y > game_map->SYSTEM_WIDTH)
  {
    return std::make_pair(0, 0);
  }

  return std::make_pair(X, Y);
}

void ASGETrek::initEnemies()
{
  srand(static_cast<unsigned>(time(nullptr)));
  max_used_enemies = (10 + ((player_rank * player_rank) * 2));
  for (int i = 0; i < max_used_enemies; i++)
  {
    bool not_placed = true;

    while (not_placed)
    {
      int rng_x      = rand() % 7 + 1;
      int rng_y      = rand() % 7 + 1;
      int rng_system = rand() % 63;
      int rng_hp_val = rand() % 25 - 10;
      auto& get_target_tile =
        game_map->getLoc(std::pair{ rng_x, rng_y }, rng_system);

      if (!get_target_tile.getOccupied())
      {
        if (i > 0)
        {
          enemy[i] = std::make_unique<Enemy>(renderer.get());
          enemy[i]->getSprite()->setGlobalZOrder(100);
          if (!enemy[i]->loadTexture("/data/Images/EnemyShip.png"))
          {
            Logging::ERRORS("character image didnt load");
            return;
          }
        }
        get_target_tile.addGameObject(enemy[i].get());
        enemy[i]->setCoords(rng_x, rng_y);
        enemy[i]->setSystem(rng_system);
        enemy[i]->changeHealth(50 - rng_hp_val);

        not_placed = false;
      }
    }
  }
}

void ASGETrek::initSpaceRings()
{
  srand(static_cast<unsigned>(time(nullptr)));
  for (int i = 0; i < MAX_SPACE_RINGS; i++)
  {
    bool not_placed = true;

    while (not_placed)
    {
      int rng_x      = rand() % 8 + 1;
      int rng_y      = rand() % 8 + 1;
      int rng_system = rand() % 63;

      auto& get_target_tile =
        game_map->getLoc(std::pair{ rng_x, rng_y }, rng_system);

      if (!get_target_tile.getOccupied())
      {
        if (i > 0)
        {
          space_ring[i] = std::make_unique<Enemy>(renderer.get());
          space_ring[i]->getSprite()->setGlobalZOrder(100);

          if (!space_ring[i]->loadTexture("/data/Images/SpaceRing.png"))
          {
            Logging::ERRORS("character image didnt load");
            return;
          }
        }
        space_ring[i]->setScale(1);
        get_target_tile.addGameObject(space_ring[i].get());
        space_ring[i]->setCoords(rng_x, rng_y);
        space_ring[i]->setSystem(rng_system);
        space_ring[i]->changeHealth(-100);
        not_placed = false;
      }
    }
  }
}

// Prepare enemy and space ring images for use
void ASGETrek::firstSetup()
{
  enemy[0] = std::make_unique<Enemy>(renderer.get());
  enemy[0]->getSprite()->setGlobalZOrder(100);

  if (!enemy[0]->loadTexture("/data/Images/EnemyShip.png"))
  {
    Logging::ERRORS("character image didnt load");
    return;
  }

  space_ring[0] = std::make_unique<Enemy>(renderer.get());
  space_ring[0]->getSprite()->setGlobalZOrder(100);

  if (!space_ring[0]->loadTexture("/data/Images/SpaceRing.png"))
  {
    Logging::ERRORS("character image didnt load");
    return;
  }
}

// Add passed object to target list
void ASGETrek::addToTargets(GameObject* gameObject)
{
  targets_list.emplace_back(gameObject);
}
[[maybe_unused]] void ASGETrek::clearTargets()
{
  targets_list.clear();
}

// Set up various input types for command input
void ASGETrek::setupInput(std::string const mode)
{
  // standard settings - reset values
  if (mode == "default")
  {
    allow_Chars = true;
    allow_Ints  = false;
    MAX_CHARS   = 7;
  }
  // co-ords
  else if (mode == "coords")
  {
    allow_Chars = false;
    allow_Ints  = true;
    MAX_CHARS   = 3;
  }

  // single number
  else if (mode == "shortnumber")
  {
    MAX_CHARS   = 1;
    allow_Chars = false;
    allow_Ints  = true;
  }

  // long number
  else if (mode == "longnumber")
  {
    MAX_CHARS   = 4;
    allow_Chars = false;
    allow_Ints  = true;
  }
  else if (mode == "destruct")
  {
    allow_Chars = true;
    allow_Ints  = true;
    MAX_CHARS   = 7;
  }
}

// Check for adjacent objects.
bool ASGETrek::adjacencyCheck(
  std::pair<int, int> firstObject, std::pair<int, int> secondObject)
{
  return (firstObject.first == secondObject.first ||
          firstObject.first == secondObject.first + 1 ||
          firstObject.first == secondObject.first - 1) &&
         (firstObject.second == secondObject.second + 1 ||
          firstObject.second == secondObject.second - 1 ||
          firstObject.second == secondObject.second);
}

// Process enemy attacks in the current sector
void ASGETrek::enemyActions()
{
  GameObject* current_enemy = targets_list.at(0);
  int enemy_x               = static_cast<int>(current_enemy->getCoords().first);
  int enemy_y               = static_cast<int>(current_enemy->getCoords().second);
  player_->incomingDamage(20);
  if (player_->getHealth() <= 0)
  {
    gameOver();
  }
  shield_energy_str = "3.SHIELDS: " + std::to_string(player_->getCurrentShields());
  if (player_->getCurrentShields() == 0)
  {
    player_->setShieldsUp(false);
    shields_energy.setColour(ASGE::COLOURS::RED);
  }
  enemy_log_input += "Enemy at " + std::to_string(enemy_x) + "," +
                     std::to_string(enemy_y) + " has fired at us for 20 damage\n";

  targets_list.erase(targets_list.begin());

  if (targets_list.empty())
  {
    enemyTurn         = false;
    player_health_str = "HEALTH: " + std::to_string(player_->getHealth());
  }
}

// Create a list of enemies in the current system.
void ASGETrek::generateEnemyList()
{
  for (int i = 0; i < max_used_enemies; i++)
  {
    if (enemy[i]->getSystem() == current_system)
    {
      addToTargets(enemy[i].get());
    }
  }
  if (!targets_list.empty())
  {
    enemyTurn = true;
  }
}

// Fills the starmap with data.
void ASGETrek::generateChart()
{
  for (int i = 0; i < game_map->MAP_HEIGHT; i++)
  {
    int enemycount   = 0;
    int stationcount = 0;
    for (int j = 0; j < max_used_enemies; j++)
    {
      if (enemy[j]->getSystem() == i)
      {
        enemycount++;
      }
    }

    for (int j = 0; j < MAX_SPACE_RINGS; j++)
    {
      if (space_ring[j]->getSystem() == i)
      {
        stationcount++;
      }
    }

    if (i == current_system)
    {
      grid_texts[static_cast<size_t>(i)].setColour(ASGE::COLOURS::YELLOW);
    }
    else
    {
      grid_texts[static_cast<size_t>(i)].setColour(ASGE::COLOURS::GREEN);
    }

    if (system_known[static_cast<size_t>(i)] == 0)
    {
      grid_strings[static_cast<size_t>(i)] = "[?,?]";
      grid_texts[static_cast<size_t>(i)].setColour(ASGE::COLOURS::WHITE);
    }
    else
    {
      grid_strings[static_cast<size_t>(i)] =
        "[" + std::to_string(enemycount) + "," + std::to_string(stationcount) + "]";
      if (enemycount > 0 && i != current_system)
      {
        grid_texts[static_cast<size_t>(i)].setColour(ASGE::COLOURS::RED);
      }
    }

    grid_texts[static_cast<size_t>(i)].setString(
      grid_strings[static_cast<size_t>(i)]);
  }
}

// Sets Sectors surrounding player to visible;
void ASGETrek::revealMap()
{
  system_known[static_cast<size_t>(current_system)] = 1;

  int start_x_val = -1;
  int limit_x_val = 2;

  bool check_up   = true;
  bool check_down = true;

  if (current_system == 0 || current_system % 8 == 0)
  {
    start_x_val = 0;
  }

  if ((current_system + 1) % 8 == 0)
  {
    limit_x_val = 1;
  }

  if (current_system < game_map->SYSTEM_WIDTH)
  {
    check_up = false;
  }
  else if (current_system >= (game_map->MAP_HEIGHT - game_map->SYSTEM_WIDTH))
  {
    check_down = false;
  }

  for (int i = start_x_val; i < limit_x_val; i++)
  {
    system_known[static_cast<size_t>(current_system + i)] = 1;
    if (check_down)
    {
      system_known[static_cast<size_t>(current_system + game_map->SYSTEM_WIDTH + i)] =
        1;
    }

    if (check_up)
    {
      system_known[static_cast<size_t>(current_system - game_map->SYSTEM_WIDTH + i)] =
        1;
    }
  }
}

// Resets inputs after actions completed.
void ASGETrek::actionCompleted()
{
  action.clear();
  action_feedback.setScale(0.85F);
  feedback = "ENTER COMMAND";
  setupInput("default");
  actions_completed++;
}

// Resets log to prevent actions for exceeding screen size.
void ASGETrek::actionEntered()
{
  enemy_log_input  = "ENEMY LOG\n";
  combat_log_input = "COMBAT LOG\n";
  player_log_input = "CAPTAIN'S LOG\n";
}

// Triggered on player death or defeating all enemies.
void ASGETrek::gameOver()
{
  state             = 5;
  int score         = 0;
  int enemies_score = (defeated_enemies - max_used_enemies) * 100;
  int ship_score    = 0;
  if (player_->getHealth() <= 0)
  {
    ship_score = -2500;
  }

  int refuel_penalty = times_refueled * -100;
  int time_score     = 5000 - actions_completed * 25;
  score              = enemies_score + ship_score - refuel_penalty + time_score;

  game_over_str = "Enemies Remaining: " + std::to_string(enemies_score) +
                  "\n Ship Lost?: " + std::to_string(ship_score) +
                  "\nRefuel Penalty: " + std::to_string(refuel_penalty) +
                  "\n Time Score: " + std::to_string(time_score) +
                  "\n \n \n Total Score: " + std::to_string(score);
}
