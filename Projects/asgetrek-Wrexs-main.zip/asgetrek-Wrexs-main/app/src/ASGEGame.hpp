//
// Created by huxy on 23/02/2020.
//

#pragma once

#include "Player.hpp"
#include <Enemy.h>
#include <Engine/FileIO.h>
#include <Engine/Logger.hpp>
#include <Engine/OGLGame.h>
#include <Engine/Sprite.h>
#include <GameMap.hpp>
#include <gamelib/game_component.hpp>
#include <gamelib/text_handler.hpp>
#include <string>
#include <vector>

class ASGETrek : public ASGE::OGLGame
{
 public:
  explicit ASGETrek(const ASGE::GameSettings& settings);
  ~ASGETrek() override;

  ASGETrek(const ASGETrek&) = delete;
  ASGETrek& operator=(const ASGETrek&) = delete;

  void keyHandler(ASGE::SharedEventData data);
  void update(const ASGE::GameTime& us) override;
  void render() override;
  void fixedUpdate(const ASGE::GameTime& us) override;

 private:
  std::vector<std::unique_ptr<GameComponent>> game_components;
  std::unique_ptr<ASGE::Sprite> title_Background = nullptr;
  std::unique_ptr<ASGE::Sprite> intro_Background = nullptr;
  std::unique_ptr<ASGE::Sprite> game_Background  = nullptr;

  int key_callback_id = -1; /**< Key Input Callback ID. */
  void setupTextInput();
  void initFonts();
  bool initTitleBackground();
  [[maybe_unused]] int difficulty = 0;

  ASGE::Text input_Text{};
  ASGE::Text title_Text{};
  ASGE::Text intro_Text{};
  ASGE::Text grid_text{};
  ASGE::Text player_health{};
  ASGE::Text player_rockets{};
  ASGE::Text stored_energy{};
  ASGE::Text weapons_energy{};
  ASGE::Text shields_energy{};
  ASGE::Text enemy_log{};
  ASGE::Text combat_log{};
  ASGE::Text player_log{};
  ASGE::Text current_action{};
  ASGE::Text action_feedback{};
  ASGE::Text x_axis_display{};
  ASGE::Text y_axis_display{};
  ASGE::Text status{};
  ASGE::Text info{};
  ASGE::Text game_over{};
  ASGE::Text game_over_score{};
  std::string game_over_str;
  std::string info_str;
  std::string action;
  std::string feedback = "ENTER COMMAND";
  std::string player_health_str;
  std::string player_rocket_str;
  std::string stored_energy_str;
  std::string weapons_energy_str;
  std::string shield_energy_str;

  std::string enemy_log_input  = "ENEMY LOG\n";
  std::string combat_log_input = "COMBAT LOG\n";
  std::string player_log_input = "CAPTAIN'S LOG\n";
  std::string input_string;
  std::string player_name;
  int player_rank{ 0 };
  std::string destruct_code;
  const ASGE::Font* title{ nullptr };
  const ASGE::Font* display{ nullptr };
  const ASGE::Font* grid{ nullptr };
  bool allow_Chars{ false };
  bool allow_Ints{ false };
  float MAX_CHARS{ 7 };
  int briefing_Page{ 1 };
  int current_system = 0;
  bool input_coords  = false;
  bool warping       = false;
  bool destructing = false;
  bool command_input{ true };
  bool firing_laser{ false };
  bool firing_rocket{ false };
  int rockets_readied = 0;
  bool
  adjacencyCheck(std::pair<int, int> firstObject, std::pair<int, int> secondObject);

  void generateEnemyList();
  void revealMap();
  void gameOver();
  int max_used_enemies = 0;
  int defeated_enemies = 0;
  int times_refueled = 0;
  int actions_completed = 0;
  std::array<std::string, 64> grid_strings;
  std::array<ASGE::Text, 64> grid_texts;
  std::array<int, 64> system_known;
  int fuel_cost = 0;
  int target_system                = 0;
  const static int MAX_ENEMY       = 100;
  const static int MAX_SPACE_RINGS = 12;

  std::vector<GameObject*> targets_list;
  bool enemyTurn = false;
  bool movingEnergy= false;
  int energyFrom = 0;
  int energyTo = 0;
  void movePlayer(int x, int y);
  void initEnemies();
  void initSpaceRings();
  void enemyActions();
  void addToTargets(GameObject* gameObject);
  [[maybe_unused]] void clearTargets();

  std::unique_ptr<GameMap> game_map = std::make_unique<GameMap>(renderer.get());

  std::unique_ptr<Player> player_ = nullptr;
  std::unique_ptr<Enemy> enemy[MAX_ENEMY];
  std::unique_ptr<Enemy> space_ring[MAX_SPACE_RINGS];

  std::pair<int, int> findCoords(std::string const& str);

  int font_idx = 0;
  int state    = 0;
  void createFont(const std::string& filepath, const char* name, int pt);
  void initScreen();
  void resolveCommands();
  void stateChange();
  void setupInput(std::string mode);
  void generateChart();

  bool initIntroBackground();
  void setupGameText();
  bool initGameBackground();
  bool initPlayer();
  void warpPlayer(int x, int y);
  void firstSetup();
  void actionCompleted();
  void actionEntered();

};
