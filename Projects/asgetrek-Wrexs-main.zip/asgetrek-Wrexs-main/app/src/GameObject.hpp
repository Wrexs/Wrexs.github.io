//
// Created by zacpa on 26/11/2020.
//

#ifndef ASGETREK_GAMEOBJECT_HPP
#define ASGETREK_GAMEOBJECT_HPP

#include <Engine/Sprite.h>
#include <Engine/Renderer.h>
#include <memory>
class GameObject
{
 public:
  GameObject() = default;
  virtual ~GameObject() = default;

  [[nodiscard]] const std::unique_ptr<ASGE::Sprite>& getSprite() const;
  void setSprite(std::unique_ptr<ASGE::Sprite>&& sprite);
  virtual void render(ASGE::Renderer* renderer) const;
  std::pair<int,int> getCoords();
  void setCoords(int x,int y);
  void setSystem(int sector);
  int getSystem();
  void changeHealth(int change);
  void resetHealth(int hptotal);
  int getHealth();


  private:
  std::unique_ptr<ASGE::Sprite> sprite_ {nullptr};
  int currentXCoord = 1;
  int currentYCoord = 1;
  int current_system = 0;
  int health = 100;




};

#endif // ASGETREK_GAMEOBJECT_HPP
