//
// Created by zacpa on 02/12/2020.
//

#include "Enemy.h"
Enemy::Enemy(ASGE::Renderer* renderer)
{
  auto unique_sprite = renderer->createUniqueSprite();
  this->setSprite(std::move(unique_sprite));
}
bool Enemy::loadTexture(const std::string& texture_path)
{
  return this->getSprite()->loadTexture(texture_path);

}
void Enemy::setScale(float scale)
{
  this->getSprite()->scale(scale);
}
void Enemy::setPosition(ASGE::Point2D pos)
{

  this->getSprite()->xPos(pos.x);
  this->getSprite()->yPos(pos.y);
}
void Enemy::setWidth(float width)
{
  return this->getSprite()->width(width);
}
void Enemy::setHeight(float height)
{
  return this->getSprite()->height(height);
}
