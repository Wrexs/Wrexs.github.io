//
// Created by zacpa on 26/11/2020.
//

#ifndef ASGETREK_GAMEMAP_HPP
#define ASGETREK_GAMEMAP_HPP

#include "MapTile.hpp"
#include <array>
#include <Engine/Renderer.h>

class GameMap
{
 public:
  using MapIndex = std::pair<int, int>;
  explicit GameMap(ASGE::Renderer* renderer);
  ~GameMap() = default;

  GameMap(GameMap&&) = default;

  GameMap& operator= (GameMap&&) = default;

  void render(ASGE::Renderer* renderer);

  [[nodiscard]] const MapTile& getLoc(const MapIndex& loc, int current_system) const;
  [[nodiscard]]  MapTile& getLoc(const MapIndex& loc, int current_system) ;



  static const int  MAP_WIDTH = 64;
  static const int  MAP_HEIGHT = 64;
  static const int SYSTEM_WIDTH = 8;

 private:
  std::array<MapTile, MAP_WIDTH * MAP_HEIGHT> map_;




};

#endif // ASGETREK_GAMEMAP_HPP
