//
// Created by zacpa on 02/12/2020.
//

#ifndef ASGETREK_ENEMY_H
#define ASGETREK_ENEMY_H


#include "GameObject.hpp"
class Enemy : public GameObject
{
 public:
  explicit Enemy(ASGE::Renderer* renderer);
  bool loadTexture(const std::string& texture_path);

  void setScale(float scale);
  void setPosition(ASGE::Point2D pos);
  void setWidth(float width);
  void setHeight(float height);

 private:
  [[maybe_unused]] char id = 'E';

};


#endif // ASGETREK_ENEMY_H
