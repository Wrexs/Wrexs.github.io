//
// Created by zacpa on 26/11/2020.
//

#ifndef ASGETREK_TEXT_HANDLER_HPP
#define ASGETREK_TEXT_HANDLER_HPP
#include <string>

class text_handler
{
 public:
  static std::string getString(std::string, std::string);


 private:

};

#endif // ASGETREK_TEXT_HANDLER_HPP
