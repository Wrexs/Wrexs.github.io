//
// Created by zacpa on 26/11/2020.
//
#include "GameMap.hpp"
#include <Engine/Renderer.h>
#include <iostream>

namespace
{
  size_t  toIdx(std::pair<int, int> loc, int current_system)
  {
    return static_cast<size_t>((loc.first -1)* GameMap::SYSTEM_WIDTH + (loc.second - 1) + (current_system * GameMap::MAP_WIDTH) ) ;
  }
}
GameMap::GameMap(ASGE::Renderer* renderer)
{
  auto x_pos = 0.F;
  auto y_pos = 0.F;


  for (auto& tile : map_)
  {

    tile.background = renderer->createUniqueSprite();
    tile.background->loadTexture("data/Images/tileBackground.png");
    tile.background->width(40);
    tile.background->height(40);
    tile.background->setGlobalZOrder(20);
    tile.setPosition({ x_pos + 60, y_pos + 40 });

    x_pos += 40;
    if (x_pos >= 40 * 8)
    {
      x_pos = 0;
      y_pos += 40;
    }
    if (y_pos >= 40 * 8)
    {
     y_pos = 0;
    }

  }


}

void GameMap::render(ASGE::Renderer* renderer)
{
  for (const auto& game_tile : map_)
  {
    game_tile.render(renderer);
  }
}


const MapTile& GameMap::getLoc(const MapIndex& loc, int current_system) const
{
  return map_[toIdx(loc, current_system)];
}
MapTile& GameMap::getLoc(const GameMap::MapIndex& loc, int current_system)
{
  return map_[toIdx(loc, current_system)];
}
