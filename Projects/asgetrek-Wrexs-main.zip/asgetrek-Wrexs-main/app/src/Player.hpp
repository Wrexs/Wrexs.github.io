//
// Created by zacpa on 26/11/2020.
//

#ifndef ASGETREK_PLAYER_HPP
#define ASGETREK_PLAYER_HPP

#include "GameObject.hpp"
class Player : public GameObject
{
 public:
  explicit Player(ASGE::Renderer* renderer);
  bool loadTexture(const std::string& texture_path);
  bool isShieldsUp() const;
  void setShieldsUp(bool shieldsStatus);
  void setScale(float scale);
  void setPosition(ASGE::Point2D pos);
  void setWidth(float width);
  void setHeight(float height);
  int getRocketCount() const;
  void changeRocketCount(int RocketsUsed);
  void restock();
  int getEnergyStores() const;
  void setEnergyStores(int energyStores);
  int getWeaponsEnergy() const;
  void setWeaponsEnergy(int weaponsEnergy);
  int getCurrentShields() const;
  void setCurrentShields(int newShields);
  void incomingDamage(int damage);

 private:
  [[maybe_unused]] char id = 'p';
  int weapons_energy       = 1500;
  int stored_energy        = 3000;
  int shields_energy       = 1500;
  bool shields_up          = true;
  const int MAX_ROCKETS    = 9;
   const int MAX_ENERGY = 1500;
  int rocket_count         = MAX_ROCKETS;

};

#endif // ASGETREK_PLAYER_HPP
